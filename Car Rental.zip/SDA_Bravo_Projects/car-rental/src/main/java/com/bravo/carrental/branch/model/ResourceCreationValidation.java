package com.bravo.carrental.branch.model;

public interface ResourceCreationValidation {
}
