package com.bravo.carrental.reservation.mapper;

import com.bravo.carrental.auth.api.mapper.UserMapper;
import com.bravo.carrental.car.mapper.CarMapper;
import com.bravo.carrental.reservation.model.Reservation;
import com.bravo.carrental.reservation.model.ReservationDto;
import com.bravo.carrental.util.ModelMapper;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReservationMapper implements ModelMapper<ReservationDto, Reservation> {

    private final UserMapper userMapper = new UserMapper();
    private final CarMapper carMapper = new CarMapper();


    @Override
    public Reservation toEntity(ReservationDto dto) {
        if (dto == null) {
            return null;}
        return Reservation.builder()
                .id(dto.getId())
                .start_date(LocalDate.parse(dto.getStart_date()))
                .end_date(LocalDate.parse(dto.getEnd_date()))
                .user(userMapper.toEntity(dto.getUser()))
                .car(carMapper.toEntity(dto.getCar()))
                .build();}

    @Override
    public ReservationDto toDto(Reservation entity) {
        if (entity == null) {
            return null;}
        return ReservationDto.builder()
                .id(entity.getId())
                .start_date(entity.getStartDate())
                .end_date(entity.getEndDate())
                .user(userMapper.toDto(entity.getUser()))
                .car(carMapper.toDto(entity.getCar()))
                .build();}

    public List<ReservationDto> toDtoList(List<Reservation> entities) {
        return entities.stream()
                .map(this::toDto)
                .collect(Collectors.toList());}
}