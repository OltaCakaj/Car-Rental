package com.bravo.carrental.branch.model;

import com.bravo.carrental.car.model.ResourceCreationValidation;

public interface BranchCreationValidation extends ResourceCreationValidation {
}
