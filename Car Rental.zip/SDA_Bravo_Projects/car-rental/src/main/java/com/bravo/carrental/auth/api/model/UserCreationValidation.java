package com.bravo.carrental.auth.api.model;

public class UserCreationValidation {
}