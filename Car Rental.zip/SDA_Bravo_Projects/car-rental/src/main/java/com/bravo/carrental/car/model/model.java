package com.bravo.carrental.car.model;

public enum model {
    SUV, Sedan, Coupe, Hybrid, Electric, Convertible, Sport, Luxury
}
