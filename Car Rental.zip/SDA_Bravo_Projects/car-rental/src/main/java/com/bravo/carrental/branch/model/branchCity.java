package com.bravo.carrental.branch.model;

public enum branchCity {
    TIRANA, DURRES, VLORE, SARANDE, SHKODER, KORCE, BERAT
}
