package com.bravo.carrental.car.model;

public interface CarCreationValidation extends ResourceCreationValidation{
}
