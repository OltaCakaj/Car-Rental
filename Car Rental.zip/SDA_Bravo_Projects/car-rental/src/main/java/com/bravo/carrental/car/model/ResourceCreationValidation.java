package com.bravo.carrental.car.model;

public interface ResourceCreationValidation {
}
