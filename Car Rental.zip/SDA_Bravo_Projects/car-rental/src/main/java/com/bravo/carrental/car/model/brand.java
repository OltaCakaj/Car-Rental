package com.bravo.carrental.car.model;

public enum brand {
    BMW, Ford, MercedesBenz, Volkswagen, Peugeot, Fiat,
    Ferrari, Porsche, Lamborghini, Maserati, Jaguar
}