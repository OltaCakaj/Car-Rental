package com.bravo.carrental.car.model;

public enum status {
    RESERVED, AVAILABLE
}
