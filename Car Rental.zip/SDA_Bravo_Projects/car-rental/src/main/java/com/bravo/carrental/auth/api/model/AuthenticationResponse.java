package com.bravo.carrental.auth.api.model;

public record AuthenticationResponse(String token) {
}