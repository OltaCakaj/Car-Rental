package com.bravo.carrental.auth.api.model;

public enum UserRole {
    ADMIN, CUSTOMER, EMPLOYEE
}
