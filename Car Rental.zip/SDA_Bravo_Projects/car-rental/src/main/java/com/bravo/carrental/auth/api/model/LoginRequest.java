package com.bravo.carrental.auth.api.model;

public record LoginRequest(String userName, String password) {
}