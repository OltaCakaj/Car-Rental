package com.bravo.carrental.reservation.model;

public enum status {
    CONFIRMED,REJECTED
}
